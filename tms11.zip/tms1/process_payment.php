<?php
session_start();
error_reporting(0);
include('includes/config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $pid = intval($_POST['pkgid']); // Package ID
    $useremail = $_SESSION['login'];
    $fromdate = $_POST['fromdate'];
    $todate = $_POST['todate'];
    $comment = $_POST['comment'];
    $pickupPoint = $_POST['pickup_point'];
    $dropPoint = $_POST['drop_point'];

    // Check if payment is successful (You can implement this logic based on your payment gateway)
    $paymentSuccessful = true; // For demonstration purposes, assuming payment is successful

    if ($paymentSuccessful) {
        $status = 1; // 1 means payment received

        $sql = "INSERT INTO tblbooking(PackageId, UserEmail, FromDate, ToDate, PickupPoint, DropPoint, Comment, status) 
                VALUES(:pid, :useremail, :fromdate, :todate, :pickup_point, :drop_point, :comment, :status)";
        $query = $dbh->prepare($sql);
        $query->bindParam(':pid', $pid, PDO::PARAM_INT);
        $query->bindParam(':useremail', $useremail, PDO::PARAM_STR);
        $query->bindParam(':fromdate', $fromdate, PDO::PARAM_STR);
        $query->bindParam(':todate', $todate, PDO::PARAM_STR);
        $query->bindParam(':comment', $comment, PDO::PARAM_STR);
        $query->bindParam(':status', $status, PDO::PARAM_INT);
        $query->bindParam(':pickup_point', $pickupPoint, PDO::PARAM_STR);
        $query->bindParam(':drop_point', $dropPoint, PDO::PARAM_STR);

        $query->execute();

        // Redirect to a success page or display a success message
        header("Location: payment_success.php");
        exit();
    } else {
        // Handle payment failure
        $error = "Payment failed. Please try again.";
    }
}
?>
<!-- Add the payment form in your existing HTML -->
<form name="payment" method="post" action="process_payment.php">
    <div class="selectroom_top">
        <!-- ... (other fields) ... -->
        <div class="bnr-right">
            <label class="inputLabel">Card Number</label>
            <input class="special" type="text" name="card_number" required="">
        </div>
        <div class="bnr-right">
            <label class="inputLabel">Expiry Date</label>
            <input class="special" type="text" name="expiry_date" placeholder="MM/YY" required="">
        </div>
        <div class="bnr-right">
            <label class="inputLabel">CVV</label>
            <input class="special" type="text" name="cvv" required="">
        </div>
        <!-- ... (other fields) ... -->
    </div>
    <div class="selectroom-info animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp; margin-top: -70px">
        <ul>
            <!-- ... (other fields) ... -->
            <li class="spe" align="center">
                <button type="submit" name="submit2" class="btn-primary btn">Book</button>
            </li>
            <div class="clearfix"></div>
        </ul>
    </div>
</form>
